# BBB Permeability AI Agent Model

This mini-project trains a BBB peptide permeability classifier and exposes it as a tool/API that your AI agent can call.

It is designed for your dataset:

- BBB+ peptides: `BBB_Positive_Union_PD1_PD2(2).xlsx`
- BBB− peptides: `BBB_Negative_Common_Backgroun(2).xlsx`
- 12-amino-acid peptide sequences
- Class imbalance around 6:1

## What the model does

The final predictor combines two signals:

1. **Main model:** LightGBM on 302 biologically interpretable peptide features:
   - amino acid composition
   - position-wise one-hot encoding
   - position-wise hydrophobicity, charge, and volume
   - global physicochemical summaries

2. **Auxiliary model:** k-mer / motif model using 1–3 character n-grams.
   - This is mainly useful for improving BBB− sensitivity.
   - It is not used alone as the final model.

The final meta model uses:

```text
302 rich peptide features + k-mer probability + k-mer logit
```

Then it tunes the decision threshold on the validation set, not the test set.

## Install

```bash
cd bbb_permeability_agent
python -m venv .venv
source .venv/bin/activate   # Mac/Linux
# .venv\Scripts\activate    # Windows

pip install -r requirements.txt
```

## Train

Put your Excel files in a folder, for example:

```text
data/
  BBB_Positive_Union_PD1_PD2(2).xlsx
  BBB_Negative_Common_Backgroun(2).xlsx
```

Then run:

```bash
python train_model.py \
  --positive data/BBB_Positive_Union_PD1_PD2\(2\).xlsx \
  --negative data/BBB_Negative_Common_Backgroun\(2\).xlsx \
  --out models/bbb_model_bundle.joblib
```

On Windows PowerShell, use quotes instead:

```powershell
python train_model.py --positive "data/BBB_Positive_Union_PD1_PD2(2).xlsx" --negative "data/BBB_Negative_Common_Backgroun(2).xlsx" --out "models/bbb_model_bundle.joblib"
```

## Predict from a scientist's natural-language prompt

```bash
python predict.py \
  --model models/bbb_model_bundle.joblib \
  --prompt "Can you check whether peptide RGDPRKGRGDSY is likely to cross the BBB?"
```

Output example:

```json
[
  {
    "sequence": "RGDPRKGRGDSY",
    "p_bbb_positive": 0.742,
    "p_bbb_negative": 0.258,
    "classification": "BBB+",
    "threshold_used": 0.63,
    "confidence": "medium"
  }
]
```

## Run as an API for your AI agent

```bash
uvicorn agent_api:app --reload --host 0.0.0.0 --port 8000
```

Then call:

```bash
curl -X POST "http://localhost:8000/predict" \
  -H "Content-Type: application/json" \
  -d '{"prompt":"Please evaluate RGDPRKGRGDSY and FFWYILLLIYWF for BBB permeability."}'
```

## How to connect this to an AI agent

Your agent can use this as a tool:

```python
from src.bbb_agent.agent_tool import predict_bbb_from_prompt

result = predict_bbb_from_prompt(
    prompt="Scientist says: test peptide RGDPRKGRGDSY.",
    model_path="models/bbb_model_bundle.joblib"
)
```

## Important scientific warning

This model predicts BBB permeability from sequence patterns learned from your training data. It does **not** replace experimental validation. Use it as a prioritization/screening tool, not a final biological decision-maker.

Recommended output language:

- "Predicted BBB+ / BBB−"
- "Probability score"
- "Confidence level"
- "Experimental validation recommended"

from typing import List, Optional

from fastapi import FastAPI
from pydantic import BaseModel, Field

from src.bbb_agent.agent_tool import predict_bbb_from_prompt, predict_sequences

app = FastAPI(
    title="BBB Permeability Predictor",
    description="Predicts BBB permeability for 12-aa peptide sequences from explicit sequence input or natural-language scientist prompts.",
    version="0.1.0",
)

DEFAULT_MODEL_PATH = "models/bbb_model_bundle.joblib"


class PromptRequest(BaseModel):
    prompt: str = Field(..., description="Natural-language scientist prompt containing peptide sequences.")
    model_path: str = Field(DEFAULT_MODEL_PATH, description="Path to trained model bundle.")


class SequenceRequest(BaseModel):
    sequences: List[str] = Field(..., description="List of explicit 12-aa peptide sequences.")
    model_path: str = Field(DEFAULT_MODEL_PATH, description="Path to trained model bundle.")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/predict")
def predict_from_prompt(req: PromptRequest):
    return predict_bbb_from_prompt(prompt=req.prompt, model_path=req.model_path)


@app.post("/predict_sequences")
def predict_from_sequences(req: SequenceRequest):
    return {
        "status": "ok",
        "n_sequences": len(req.sequences),
        "predictions": predict_sequences(req.sequences, model_path=req.model_path),
    }

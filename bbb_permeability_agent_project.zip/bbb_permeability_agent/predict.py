#!/usr/bin/env python3
import argparse
import json

from src.bbb_agent.agent_tool import predict_bbb_from_prompt, predict_sequences


def parse_args():
    p = argparse.ArgumentParser(description="Predict BBB permeability from peptide sequence or natural-language prompt.")
    p.add_argument("--model", required=True, help="Path to trained .joblib model bundle")
    p.add_argument("--sequence", action="append", help="Explicit 12-aa sequence. Can be used multiple times.")
    p.add_argument("--prompt", help="Natural-language prompt containing one or more peptide sequences.")
    return p.parse_args()


def main():
    args = parse_args()

    if args.sequence:
        result = {
            "status": "ok",
            "n_sequences": len(args.sequence),
            "predictions": predict_sequences(args.sequence, model_path=args.model)
        }
    elif args.prompt:
        result = predict_bbb_from_prompt(args.prompt, model_path=args.model)
    else:
        raise SystemExit("Provide --sequence or --prompt")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

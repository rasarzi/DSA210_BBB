#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from src.bbb_agent.data import load_positive_negative_files
from src.bbb_agent.features import featurize_sequences
from src.bbb_agent.modeling import (
    build_kmer_pipeline,
    build_main_model,
    build_meta_model,
    choose_threshold,
    compute_metrics,
    make_meta_features,
    predict_proba_positive,
    save_bundle,
)


def parse_args():
    p = argparse.ArgumentParser(description="Train BBB peptide permeability model.")
    p.add_argument("--positive", required=True, help="Path to BBB+ Excel/CSV file")
    p.add_argument("--negative", required=True, help="Path to BBB- Excel/CSV file")
    p.add_argument("--out", default="models/bbb_model_bundle.joblib", help="Output model bundle path")
    p.add_argument("--report", default="models/training_report.json", help="Output report JSON path")
    p.add_argument("--threshold-mode", default="mcc",
                   choices=["mcc", "balanced_accuracy", "bbb_negative_f2", "bbb_negative_recall_precision30"],
                   help="Validation metric used to choose threshold")
    p.add_argument("--random-state", type=int, default=42)
    return p.parse_args()


def main():
    args = parse_args()
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    os.makedirs(os.path.dirname(args.report) or ".", exist_ok=True)

    df = load_positive_negative_files(args.positive, args.negative)
    sequences = df["sequence"].values
    y = df["label"].values.astype(int)

    # Train / validation / test = 70 / 15 / 15
    seq_train, seq_temp, y_train, y_temp = train_test_split(
        sequences, y, test_size=0.30, stratify=y, random_state=args.random_state
    )
    seq_val, seq_test, y_val, y_test = train_test_split(
        seq_temp, y_temp, test_size=0.50, stratify=y_temp, random_state=args.random_state
    )

    print(f"Train: {len(seq_train):,} | Val: {len(seq_val):,} | Test: {len(seq_test):,}")

    print("Building rich peptide features...")
    X_train = featurize_sequences(seq_train)
    X_val = featurize_sequences(seq_val)
    X_test = featurize_sequences(seq_test)

    # Weight BBB- more heavily. Labels: BBB+ = 1, BBB- = 0.
    n_pos = int((y_train == 1).sum())
    n_neg = int((y_train == 0).sum())
    neg_weight = n_pos / max(n_neg, 1)
    sample_weight = np.where(y_train == 0, neg_weight, 1.0)

    print(f"BBB- training weight: {neg_weight:.3f}")

    print("Training main rich-feature model...")
    main_model = build_main_model(random_state=args.random_state)

    try:
        main_model.fit(
            X_train,
            y_train,
            sample_weight=sample_weight,
            eval_set=[(X_val, y_val)],
        )
    except TypeError:
        # Some sklearn pipelines do not accept sample_weight directly.
        main_model.fit(X_train, y_train)

    print("Training k-mer auxiliary model...")
    kmer_model = build_kmer_pipeline()
    # ComplementNB accepts sample weights through pipeline only with step name.
    try:
        kmer_model.fit(seq_train, y_train, clf__sample_weight=sample_weight)
    except TypeError:
        kmer_model.fit(seq_train, y_train)

    print("Creating meta features...")
    p_main_train = predict_proba_positive(main_model, X_train)
    p_main_val = predict_proba_positive(main_model, X_val)
    p_main_test = predict_proba_positive(main_model, X_test)

    p_kmer_train = predict_proba_positive(kmer_model, seq_train)
    p_kmer_val = predict_proba_positive(kmer_model, seq_val)
    p_kmer_test = predict_proba_positive(kmer_model, seq_test)

    X_meta_train = make_meta_features(X_train, p_main_train, p_kmer_train)
    X_meta_val = make_meta_features(X_val, p_main_val, p_kmer_val)
    X_meta_test = make_meta_features(X_test, p_main_test, p_kmer_test)

    print("Training stacked meta model...")
    meta_model = build_meta_model(random_state=args.random_state)
    try:
        meta_model.fit(X_meta_train, y_train, clf__sample_weight=sample_weight)
    except TypeError:
        meta_model.fit(X_meta_train, y_train)

    p_meta_val = predict_proba_positive(meta_model, X_meta_val)
    p_meta_test = predict_proba_positive(meta_model, X_meta_test)

    chosen_threshold, val_threshold_metrics = choose_threshold(
        y_val,
        p_meta_val,
        mode=args.threshold_mode
    )

    test_metrics = compute_metrics(y_test, p_meta_test, threshold=chosen_threshold)

    report = {
        "model_type": "stacked_rich_features_plus_kmer",
        "label_mapping": {"BBB-": 0, "BBB+": 1},
        "expected_length": 12,
        "threshold_mode": args.threshold_mode,
        "chosen_threshold": chosen_threshold,
        "train_size": int(len(seq_train)),
        "validation_size": int(len(seq_val)),
        "test_size": int(len(seq_test)),
        "n_positive_total": int((y == 1).sum()),
        "n_negative_total": int((y == 0).sum()),
        "bbb_negative_weight": float(neg_weight),
        "validation_threshold_metrics": val_threshold_metrics,
        "test_metrics": test_metrics,
    }

    bundle = {
        "expected_length": 12,
        "label_mapping": {"BBB-": 0, "BBB+": 1},
        "main_model": main_model,
        "kmer_model": kmer_model,
        "meta_model": meta_model,
        "chosen_threshold": chosen_threshold,
        "threshold_mode": args.threshold_mode,
        "report": report,
    }

    save_bundle(bundle, args.out)

    with open(args.report, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    print("\nFinal test metrics")
    print(json.dumps(test_metrics, indent=2))
    print(f"\nSaved model: {args.out}")
    print(f"Saved report: {args.report}")


if __name__ == "__main__":
    main()
